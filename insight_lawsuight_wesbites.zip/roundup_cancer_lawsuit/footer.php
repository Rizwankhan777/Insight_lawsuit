<footer class="footer_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="content">
                <p>Attorney Advertising Disclaimer: The information you obtain at this site is not, nor is it intended to be, legal advice. You should consult an attorney for advice regarding your individual situation. We invite you to contact us and welcome your calls, letters and electronic mail. Contacting us does not create an attorney-client relationship. Please do not send any confidential information to us until such time as an attorney-client relationship has been established. Prior results do not guarantee a similar outcome.

</p>
                   <p class="pt-3">Privacy Policy</p>
			</div>
                </div>
            </div>
        </div>
    </footer>


<!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/jquery.fancybox.min.js"></script>
<script src="js/popper-min.js"></script>
<script src="js/bootstrap.min.js"></script> 
<script src="js/owl.carousel.min.js"></script>
<script src="js/custom.js"></script> 


</body>
</html>
