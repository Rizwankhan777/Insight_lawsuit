<?php include 'header.php';?>

	<section class="banner_section web2">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-3">
					<div class="img-div">
						<img src="./images/spray_img.svg" class="spray_img img-fluid" alt="">
					</div>
				</div>
				<div class="col-md-4">
					<div class="content_side">
						<h1>ATTENTION:</h1>
						<h4>If You Have Cancer & Have Used Roundup, You May be Entitled to Significant Compensation</h4>
						<ul>
							<li> Roundup’s main ingredient, Glyphosate, has been proven to cause cancer by the World Health Organization</li>
							<li>To date, the makers of Roundup have agreed to pay <span>$11 Billion to Victims</span></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form_div">
						<div class="form_top">
						<h4>Find Out If You Qualify</h4>
						<p><span>Significant</span> Compensation May Be Available</p>
						
						</div>
						<form action="" >
							<label for="">Have you used or been exposed to Roundup Weed Killer for at least one year?</label>
							<select name="" class="form-control mb-3" id="" >
								<option value="" muted disabled selected>-- Select one --</option>
								<option value="">Yes</option>
								<option value="">No</option>
								

							</select>
							<label for="">Which of the following cancers do you suffer from?
</label>
							<select name="" class="form-control mb-3" id="">
							<option value="" muted disabled selected>-- Select one --</option>
							<option value="">Anaplastic Large T/Null-Cell Lymphoma (T/N-ALCL)</option>
							<option value="">B-Cell Lymphoma</option>
							<option value="">Burkitt Lymphoma (B-BL)</option>
							<option value="">Chronic Lymphocytic Leukemia (CLL)</option>
							<option value="">Diffuse Large B-Cell Lymphoma (B-DLCL)</option>
							<option value="">Follicular Lymphoma (B-FL)</option>
							<option value="">Hairy Cell Leukemia (HCL)</option>
							<option value="">Mantle Cell Lymphoma (MCL)</option>
							<option value="">Mycosis Fungoides (T-MF)</option>
							<option value="">Non-Hodgkin's Lymphoma (NHL)</option>
							<option value="">Plasmacytoma (B-PC)</option>
							<option value="">Sezary Syndrome (T-SS)</option>
							<option value="">Small Lymphocytic Lymphoma (B-SLL)</option>
							<option value="">T-Cell Lymphoma</option>
							<option value="">Other Lymphoma Cancer</option>
							<option value="">Other Cancer</option>
							<option value="">No Cancer</option>
							
							</select>
						
							<div class="form-group">
								<label for="">first Name <span>*</span></label>
								<input type="text" name="first_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Last Name <span>*</span></label>
								<input type="text" name="last_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Email <span>*</span></label>
								<input type="email" name="email" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Phone Number <span>*</span></label>
								<input type="number" name="phone_no" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Briefly describe what happened (Optional)</label>
								<textarea name="" class="form-control" id="" cols="30" rows="4"></textarea>
							</div>
						 <p>
						 <div class="btn-div">
                                <a href="javascript:;">See If I qualify?</a>
                            </div>
							<div class="img-div py-3 text-center">
								<img src="./images/c_s_img.png" class="img-fluid" alt="">
							</div>
							<p>
							By clicking 'Do I Qualify' and submitting my request, I confirm that I have read and agree to the privacy policy of this site and that I consent to receive emails, phone calls and/or text message offers and communications from Total Injury Help, Digital Activity, and its network of lawyers and advocates at any telephone number or email address provided by me, including my wireless number, if provided. I understand there may be a charge by my wireless carrier for such communications. I understand these communications may be generated using an autodialer and may contain pre-recorded messages and that consent is not required to utilize Total Injury Help services. I understand that this authorization overrides any previous registrations on a federal or state Do Not Call registry. Accurate information is required for a free evaluation.

</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="first_wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul>
						<li><h4>As Seen On:</h4></li>
						<li>
							<img src="./images/ab_new_img.png" alt="">
						</li>
						<li>
							<img src="./images/fox_new_img.webp" alt="">
						</li>
						<li>
							<img src="./images/n_y_t_img.png" alt="">
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="second_wrap web2_wrap2">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-12">
							<div class="content">
								<h2>
								More than 100,000 people have already been awarded settlements with more expected soon</h2>
<ul>
<li><p>The makers of Roundup have <span>agreed to pay $11 Billion to victims,</span> with additional settlements expected.</p></li>
<li><p>Common settlement amounts range from <span>$5,000 and $250,000,</span> depending on the case.</p></li>
<li><p>Multiple cases have already been <span>awarded millions of dollars,</span> with one couple receiving a <span>$2 Billion settlement</span> for their individual case</p></li>
<h3>Time is Limited - See if you qualify TODAY!
</h3>
</ul>
							</div>
						</div>
						
					</div>

					
				</div>
			</div>
		</div>
	</section>

	<section class="running_out_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 ">
                    <h3>Many victims have already received huge settlements from the makers of Roundup</h3>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>COUPLE AWARDED $2 BILLION IN ROUNDUP LAWSUIT</h4>
                        <p>A California jury has ruled in favor of a couple that used Roundup for decades to kill weeds on their properties. Both the husband and wife contracted non-Hodgkin’s lymphoma and a jury concluded their years of using Roundup contributed to the cause of their cancer.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>
SCHOOL GROUNDSKEEPER AWARDED $289 MILLION IN ROUNDUP LAWSUIT</h4>
                        <p>A school groundskeeper was recently awarded $289 million in a lawsuit against Monsanto (the makers of Roundup). The jury claimed that Monsanto had failed to warn consumers of the risk of using Roundup.


                        </p>


                    </div>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>JURY AWARDS $80 MILLION TO HOMEOWNER IN ROUNDUP LAWSUIT</h4>
                        <p>A homeowner that used Roundup for years on his property to comabat Poison Oak was recently awarded $80 million. A six-person jury came to the verdict unanimously. The jury claimed Monsanto misled the man, and the product contributed to causing his non-Hodgkin’s lymphoma.


                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>

	<section class="green_shad">
		<div class="container">
			<div class="row">
				<div class="col-md-8 mx-auto">
                <div class="content">
					<h6>
Do you have <span>cancer,</span> and have used <span>Roundup</span>?</h6>
<h3>See how much your claim could be worth</h3>
<div class="btn-div">
                                <a href="javascript:;">WHAT'S MY CLAIM WORTH?</a>
                            </div>
				</div>
				</div>
			</div>
		</div>
	</section>

<?php include 'footer.php';?>

