<?php include 'header.php';?>

	<section class="banner_section web2">
		<div class="container">
			<div class="row">
			
				<div class="col-md-7">
					<div class="content_side">
						<h1>ATTENTION:</h1>
						<h4>Did you or a loved one work, live, or serve at Camp Lejeune? You may be entitled to <span>SIGNIFICANT Compensation</span>


</h4>
						<h5>For more than 10 years, our team has specialized in helping veterans and their families. We'll handle everything from filing your claim to fighting for the highest possible settlement. <span>Find Out if You Qualify Today!</span>
</h5>
<h3>Time is Limited - More than 14,000 people have already filed claims!


</h3>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form_div">
						<div class="form_top">
						<h4>Find Out If You Qualify</h4>
						<p><span>Significant</span> Compensation May Be Available</p>
						
						</div>
						<form action="" >
							<label for="">Did you or a loved one serve, live, or work at Camp Lejeune for at least 30 days between 1953 and 1987?</label>
							<select name="" class="form-control mb-3" id="" >
								<option value="" muted disabled selected>-- Select one --</option>
								<option value="">Yes</option>
								<option value="">No</option>
								

							</select>
							<label for="">What injury were you or your loved one diagnosed with?

</label>
<select autocomplete="off"  class="form-input form-control required   " data-at="form-select" name="What injury were you or your loved one diagnosed with?" data-describedby="form-validation-error-box-element-516" title="What injury were you or your loved one diagnosed with?" required="" aria-required="true">
      <option class="hidden" value="" disabled="" selected="">-- Select one--</option>
      <option class="form-select-option" value="Aplastic anemia" data-at="form-select-option">Aplastic anemia</option>
      <option class="form-select-option" value="Amyotrophic Lateral Sclerosis (ALS)" data-at="form-select-option">Amyotrophic Lateral Sclerosis (ALS)</option>
      <option class="form-select-option" value="Birth defects (non-cardiac)" data-at="form-select-option">Birth defects (non-cardiac)</option>
      <option class="form-select-option" value="Bladder cancer" data-at="form-select-option">Bladder cancer</option>
      <option class="form-select-option" value="Brain cancer" data-at="form-select-option">Brain cancer</option>
      <option class="form-select-option" value="Breast Cancer" data-at="form-select-option">Breast Cancer</option>
      <option class="form-select-option" value="Cardiac birth defects" data-at="form-select-option">Cardiac birth defects</option>
      <option class="form-select-option" value="Cervical cancer" data-at="form-select-option">Cervical cancer</option>
      <option class="form-select-option" value="Esophageal cancer" data-at="form-select-option">Esophageal cancer</option>
      <option class="form-select-option" value="Female Infertility (while exposed to CL water)" data-at="form-select-option">Female Infertility (while exposed to CL water)</option>
      <option class="form-select-option" value="Fetal death (loss > 20 weeks)" data-at="form-select-option">Fetal death (loss &gt; 20 weeks)</option>
      <option class="form-select-option" value="Hepatic steatosis (fatty liver disease)" data-at="form-select-option">Hepatic steatosis (fatty liver disease)</option>
      <option class="form-select-option" value="Kidney cancer" data-at="form-select-option">Kidney cancer</option>
      <option class="form-select-option" value="Kidney disease" data-at="form-select-option">Kidney disease</option>
      <option class="form-select-option" value="Leukemia" data-at="form-select-option">Leukemia</option>
      <option class="form-select-option" value="Lung cancer" data-at="form-select-option">Lung cancer</option>
      <option class="form-select-option" value="Liver cancer" data-at="form-select-option">Liver cancer</option>
      <option class="form-select-option" value="MDS (Myelodysplastic syndromes)" data-at="form-select-option">MDS (Myelodysplastic syndromes)</option>
      <option class="form-select-option" value="Multiple myeloma" data-at="form-select-option">Multiple myeloma</option>
      <option class="form-select-option" value="Miscarriage (loss < 20 weeks while exposed to CL water)" data-at="form-select-option">Miscarriage (loss &lt; 20 weeks while exposed to CL water)</option>
      <option class="form-select-option" value="Neural tube defects" data-at="form-select-option">Neural tube defects</option>
      <option class="form-select-option" value="Non-Hodgkin's lymphoma" data-at="form-select-option">Non-Hodgkin's lymphoma</option>
      <option class="form-select-option" value="Pancreatic cancer" data-at="form-select-option">Pancreatic cancer</option>
      <option class="form-select-option" value="Parkinson's disease" data-at="form-select-option">Parkinson's disease</option>
      <option class="form-select-option" value="Rectal cancer" data-at="form-select-option">Rectal cancer</option>
      <option class="form-select-option" value="Renal toxicity" data-at="form-select-option">Renal toxicity</option>
      <option class="form-select-option" value="Scleroderma" data-at="form-select-option">Scleroderma</option>
      <option class="form-select-option" value="Soft tissue sarcoma" data-at="form-select-option">Soft tissue sarcoma</option>
      <option class="form-select-option" value="Other cancer" data-at="form-select-option">Other cancer</option>
      <option class="form-select-option" value="Other injury" data-at="form-select-option">Other injury</option>
      <option class="form-select-option" value="No injury" data-at="form-select-option">No injury</option>
  </select>
						
							<div class="form-group">
								<label for="">first Name <span>*</span></label>
								<input type="text" name="first_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Last Name <span>*</span></label>
								<input type="text" name="last_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Email <span>*</span></label>
								<input type="email" name="email" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Phone Number <span>*</span></label>
								<input type="number" name="phone_no" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Briefly describe what happened (Optional)</label>
								<textarea name="" class="form-control" id="" cols="30" rows="4"></textarea>
							</div>
						 <p>
						 <div class="btn-div">
                                <a href="javascript:;">Do I qualify?</a>
                            </div>
							<div class="img-div py-3 text-center">
								<img src="./images/c_s_img.png" class="img-fluid" alt="">
							</div>
							<p>
							By clicking 'Do I Qualify' and submitting my request, I confirm that I have read and agree to the privacy policy of this site and that I consent to receive emails, phone calls and/or text message offers and communications from Total Injury Help, Digital Activity, and its network of lawyers and advocates at any telephone number or email address provided by me, including my wireless number, if provided. I understand there may be a charge by my wireless carrier for such communications. I understand these communications may be generated using an autodialer and may contain pre-recorded messages and that consent is not required to utilize Total Injury Help services. I understand that this authorization overrides any previous registrations on a federal or state Do Not Call registry. Accurate information is required for a free evaluation.

</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="first_wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul>
						<li><h4>As Seen On:</h4></li>
						<li>
							<img src="./images/ab_new_img.png" alt="">
						</li>
						<li>
							<img src="./images/forb_img.webp" alt="">
						</li>
						<li>
							<img src="./images/n_y_t_img.png" alt="">
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="second_wrap web2_wrap2">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-12">
							<div class="content">
								<h2>		
Camp Lejeune water contamination settlement amounts are estimated to be <span>$6.7 billion</span></h2>
<div class="img-div text-center py-3">
	<img src="./images/camp_img11.png" alt="">
</div>
<h4>How to Qualify for a Settlement</h4>
<p>If you or a loved one lived, worked, or served at Camp Lejeune between 1953 - 1987, you may qualify.</p>
<h4>How our Team can Help You</h4>
<p>A new law passed in 2022 allows affected veterans and their families to file a claim to receive compensation for illnesses or death caused by contaminated water at Camp Lejeune.</p>
<p>The process for filing a claim is very complex and any errors in your application can result in your claim being denied. Our legal team are experts in these types of claims and will guarantee that everything is filed correctly and fight to get you the highest possible settlement amount.</p>
<h5>Our services are provided at <span>NO RISK</span> to you. You won’t pay anything until we win your case.
</h5>
							</div>
						</div>
						
					</div>

					
				</div>
			</div>
		</div>
	</section>

	<section class="running_out_section">
        <div class="container">
            <div class="row">
			<div class="col-md-12">
                    <h2>Thousands of Marines and their families unknowingly drank contaminated water for more than 30 years</h2>
                <p>Water testing in 1982 found that drinking water at Camp Lejeune was contaminated with dangerous chemicals known to be carcinogenic or harmful to humans. <span>Contamination of water was documented at up to 300 times acceptable levels in some cases.</span> These dangers were ignored and many innocent Marines & their families have developed very serious illnesses or death because of the water they consumed.</p>
				</div>
				<div class="col-md-5">
                <div class="img-div">
					<img src="./images/map_img.webp" alt="">
				</div>
				</div>
				<div class="col-md-6">
                   <h5>If you or a loved one developed any of these conditions, you may be entitled to significant compensation:</h5>
				  

             
				  <div class="d-flex">
				  <ul>
				   <li> <span>></span> Breast cancer</li>
<li> <span>></span> Cardiac birth defects</li>
<li> <span>></span>  Esophageal cancer</li>
<li> <span>></span> Female infertility</li>
<li> <span>></span> Hepatic steatosis</li>
<li> <span>></span> Kidney cancer</li>
<li> <span>></span> Leukemia</li>
<li> <span>></span> Liver cancer</li>
<li> <span>></span> Lung cancer</li>
				   </ul>
				   <ul class="ml-5">
				   <li><span>></span> MDS(Myelodysplastic syndromes)</li>
<li><span>></span> Miscarriage</li>
<li><span>></span> Multiple myeloma</li>
<li><span>></span> Neurobehavioral effects</li>
<li><span>></span> Non-Hodgkin’s lymphoma</li>
<li><span>></span> Parkinson’s disease</li>
<li><span>></span> Renal toxicity</li>
<li><span>></span> Scleroderma</li>
<li><span>></span> Other injury</li>
				   </ul>
				  
				  </div>
				  <div class="btn-div">
                                <a href="javascript:;">
      See if I Qualify for Compensation ➔
  </a>
                            </div>
				</div>
                <div class="col-md-12 ">
                    <h3>
Get your free Claim Evaluation in a few simple steps</h3>
                </div>
				<div class="col-md-4">
                    <div class="content">
                        <h4>1. Complete the Form </h4>
                        <p>Time is limited. Complete the form today to make sure you have the best chance to recieve the justice you deserve.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>2. Free Case Review</h4>
                        <p>Our team will call you as soon as possible to discuss how to get the settlement you deserve. This is completely free with no obligations.



                        </p>


                    </div>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>3. Possible Compensation</h4>
                        <p>Your attorney will fight for you to receive the highest possible compensation. There are no risks or up-front costs to you.



                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
<section class="camp_lejeune_section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>
Camp Lejeune Justice Act of 2022</h1>
</div>
<div class="col-md-7">
	<p>In June 2022, the US Senate passed the Honoring our Pact Act with a bipartisan vote of 84-13. This act includes critical support for victims of Camp Lejenue water contamination, and allows impacted individuals to file a claim for significant compensation.</p>
	<p>Many of these individuals who developed severe illneses due to government negligence at Camp Lejenue have had their claims inappropriately denied or delayed by the VA, resulting in additional harm.
</p>
	<p>People or loved ones of those who lived, worked, or were stationed at Camp Lejeune who experienced a water toxicity-related illness may now be eligible for a significant settlement.
</p>
<p>Contact our expert team today to get the justice that you deserve!</p>

			</div>
			<div class="col-md-5 align-self-center">
				<div class="img-div">
					<img src="./images/camp_img2.png" class="img-fluid" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
	<section class="green_shad">
		<div class="container">
			<div class="row">
				<div class="col-md-8 mx-auto">
                <div class="content">
					<h6>
					There is NO upfront cost to using the attorneys and the consultation is 100% free of charge.</h6>
<p>In the event, they win your case, your attorneys will receive a contingency fee based on the funds they recover to pay for costs.</p>
<h5>You pay nothing unless you win.</h5>
<div class="btn-div">
                                <a href="javascript:;">See if I Qualify for Compensation ➔</a>
                            </div>
				</div>
				</div>
			</div>
		</div>
	</section>

<?php include 'footer.php';?>

