<?php include 'header.php';?>

	<section class="banner_section web2">
		<div class="container">
			<div class="row">
			
				<div class="col-md-7">
					<div class="content_side">
						<h1>ATTENTION:</h1>
						<h4>If exposure to AFFF has left you suffering from a form of cancer or other serious health effects, you could be entitled to <span>significant compensation</span></h4>
						<ul>
							<li>Average settlement payouts are estimated to be between <span>$300,000 to $450,000,</span> depending on the case
</li>
							<li>
Time is Limited - See if you qualify TODAY!</li>
						</ul>
					</div>
				</div>


				


				<div class="col-md-5">
					<div class="form_div">
						<div class="form_top">
						<h4>Find Out If You Qualify</h4>
						<p><span>Significant</span> Compensation May Be Available</p>
						
						</div>
						<form action="" >
							<div class="form-group row">
							<div class="col-md-12">
							<label for="">Were you exposed to firefighting foam (AFFF)?</label>
							</div>
								<div class="col-md-12 text-center">
								<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label class_yes" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label class_no" for="inlineRadio2">No</label>
</div>
								</div>
							</div>
							<label for="">Were you or someone you know diagnosed with any of the following?</label>
							<select autocomplete="off"  class="form-input form-control required" data-at="form-select" name="Were you or someone you know diagnosed with any of the following?" data-describedby="form-validation-error-box-element-516" title="Were you or someone you know diagnosed with any of the following?" required="" aria-required="true" aria-invalid="false">
      <option class="hidden" value="" disabled="" selected="">-- Select one--</option>
      <option class="form-select-option" value="Bladder cancer" data-at="form-select-option">Bladder cancer</option>
      <option class="form-select-option" value="Breast cancer" data-at="form-select-option">Breast cancer</option>
      <option class="form-select-option" value="Hodgkin's lymphoma" data-at="form-select-option">Hodgkin's lymphoma</option>
      <option class="form-select-option" value="Kidney cancer" data-at="form-select-option">Kidney cancer</option>
      <option class="form-select-option" value="Leukemia" data-at="form-select-option">Leukemia</option>
      <option class="form-select-option" value="Liver cancer" data-at="form-select-option">Liver cancer</option>
      <option class="form-select-option" value="Multiple Myeloma" data-at="form-select-option">Multiple Myeloma</option>
      <option class="form-select-option" value="Non-Hodgkin's Lymphoma" data-at="form-select-option">Non-Hodgkin's Lymphoma</option>
      <option class="form-select-option" value="Ovarian cancer" data-at="form-select-option">Ovarian cancer</option>
      <option class="form-select-option" value="Pancreatic cancer" data-at="form-select-option">Pancreatic cancer</option>
      <option class="form-select-option" value="Preeclampsia" data-at="form-select-option">Preeclampsia</option>
      <option class="form-select-option" value="Prostate cancer" data-at="form-select-option">Prostate cancer</option>
      <option class="form-select-option" value="Skin cancer" data-at="form-select-option">Skin cancer</option>
      <option class="form-select-option" value="Testicular cancer" data-at="form-select-option">Testicular cancer</option>
      <option class="form-select-option" value="Thyroid cancer" data-at="form-select-option">Thyroid cancer</option>
      <option class="form-select-option" value="Thyroid disease" data-at="form-select-option">Thyroid disease</option>
      <option class="form-select-option" value="Ulcerative Colitis" data-at="form-select-option">Ulcerative Colitis</option>
      <option class="form-select-option" value="No injury" data-at="form-select-option">No injury</option>
      <option class="form-select-option" value="Other cancer" data-at="form-select-option">Other cancer</option>
      <option class="form-select-option" value="Other injury" data-at="form-select-option">Other injury</option>
  </select>
							
							<div class="form-group">
								<label for="">first Name <span>*</span></label>
								<input type="text" name="first_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Last Name <span>*</span></label>
								<input type="text" name="last_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Email <span>*</span></label>
								<input type="email" name="email" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Phone Number <span>*</span></label>
								<input type="number" name="phone_no" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Briefly describe what happened (Optional)</label>
								<textarea name="" class="form-control" id="" cols="30" rows="4"></textarea>
							</div>
						 <p>
						 <div class="btn-div">
                                <a href="javascript:;">Do I qualify?</a>
                            </div>
							<div class="img-div py-4 text-center">
								<img src="./images/c_s_img.png" class="img-fluid" alt="">
							</div>
							<p>
By clicking 'Do I Qualify' and submitting my request, I confirm that I have read and agree to the privacy policy of this site and that I consent to receive emails, phone calls and/or text message offers and communications from Total Injury Help, Digital Activity, and its network of lawyers and advocates at any telephone number or email address provided by me, including my wireless number, if provided. I understand there may be a charge by my wireless carrier for such communications. I understand these communications may be generated using an autodialer and may contain pre-recorded messages and that consent is not required to utilize Total Injury Help services. I understand that this authorization overrides any previous registrations on a federal or state Do Not Call registry. Accurate information is required for a free evaluation.</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="first_wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul>
						<li><h4>As Seen On:</h4></li>
						<li>
							<img src="./images/wal_st_img.png" alt="">
						</li>
						<li>
							<img src="./images/fox_new_img.webp" alt="">
						</li>
						<li>
							<img src="./images/cbs_img.webp" alt="">
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="second_wrap web2_wrap2">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-12">
							<div class="content">
								<h2>
								Aqueous Film-Forming Foam (AFFF) contain harmful chemicals called PFAS that have been linked to several types of cancer</h2>
                  <h6>AFFF, a common firefighting agent used by military and civilian firefighters has been found to contain harmful chemicals such as PFAS that are believed to cause several types of cancer as a result of regular exposure.</h6>
				  <h2>AFFF has been found to contain PFAS, known as “forever chemicals”
</h2>
<h6>PFAS are referred to as forever chemicals because once they enter your body, they do not break down over time, potentially leading to lifelong health issues:</h6>
							</div>
						</div>
						
					</div>
				</div>
				<div class="col-md-7  py-3">
                    <div class="row">
					<ul>
						 <li>Kidney cancer</li>
						<li>Testicular cancer</li>
						<li>Bladder cancer</li>
						<li>Liver cancer</li>
						<li>Breast cancer</li>
						 </ul>
						 <ul class="ml-5">
						 <li> Pancreatic cancer </li>
 <li> Prostate cancer </li>
 <li> Leukemia </li>
 <li> Non-Hodgkin's Lymphoma </li>
						 </ul>
					</div>
				<div class="content">
				<h6 class="pt-5 pb-3">If you developed Cancer after being exposed to PFFF, you may qualify for significant compensation.</h6>
				<h6>Time is limited. See if you qualify TODAY!
</h6>
<div class="btn-div">
                                <a href="javascript:;">See if I Qualify for Compensation ➔</a>
                            </div>
				</div>
						</div>
						<div class="col-md-5">
                        <div class="img-div">
						<img src="./images/fire_img.svg" class="img-fluid" alt="">
						</div>
						</div>
			</div>
		</div>
	</section>

	<section class="claim_review_section">
		<div class="container">
			<div class="row">
				<div class="col-md-12 ">
<h1><span>No Obligation Claim Review:</span> Quick, easy, and 100% free.</h1>
				</div>
				<div class="col-md-4">
					<div class="content">
						<div class="img-div">
							<img src="./images/claim_1.svg" class="img-fluid" alt="">
						</div>
						<h4>Complete the Form</h4>
						<p>Complete the form on this page to determine if you qualify. It only takes a couple minutes.

</p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="content">
						<div class="img-div">
							<img src="./images/claim_2.svg" class="img-fluid" alt="">
						</div>
						<h4>Claim Review
</h4>
						<p>We’ll contact you to discuss your options and get the information needed to get you the settlement you deserve.



</p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="content">
						<div class="img-div">
							<img src="./images/claim_3.svg" class="img-fluid" alt="">
						</div>
						<h4>Possible Compensation
</h4>
						<p>If you qualify, you will have the option to work with an attorney that will fight to get you the highest possible settlement.



</p>
					</div>
				</div>
				<div class="col-md-10 mx-auto ">
					<p class="m-content">There is absolutely no risk, <span>no obligation, and no upfront cost.</span> If you qualify, we will discuss your options with you to allow you to make an informed decision that is best for you.</p>
					<p class="m-content">If you decide to work with our team, we’ll fight to get the highest possible settlement. </p>
					<h3>We only get paid if we win your case.</h3>
					<div class="btn-div">
                                <a href="javascript:;">Find Out If You qualify?</a>
                            </div>
				</div>
			</div>
		</div>
	</section>
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="content">
					
				</div>
			</div>
		</div>
	</div>
</section>
<section class="health_concerns_section">
	<div class="container">
		<div class="row">
			<div class="col-md-10 mx-auto">
				<div class="row">
				<div class="col-md-6">
            <div class="content">
				<div class="img-div">
					<img src="./images/hc_img.png" class="img-fluid" alt="">
				</div>
				<h2>Health Concerns</h2>
				<p>The Environmental Working Group (EWG) and Centers for Disease Control and Prevention (CDC) both warn that exposure to firefighting foam or water contaminated with PFAS can increase the risk of cancer. Because AFFF contains PFAS there is evidence of a link between firefighting foam and certain cancers.</p>

			</div>
			</div>
			<div class="col-md-6">
            <div class="content">
				<div class="img-div">
				<img src="./images/cost_img.png" class="img-fluid" alt="">
				</div>
				<h2>Costs</h2>
				<p>Treatments for these types of conditions can be extremely expensive. Ultimately, exposure to firefighting foam could mean a lifetime of suffering—and struggling to pay staggering hospital bills. If this is your experience, it’s time to be proactive about compensation for your pain.</p>
				
			</div>
			</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="green_shad">
		<div class="container">
			<div class="row">
				<div class="col-md-8 mx-auto">
                <div class="content">
					<h6>
					There is NO upfront cost to using the attorneys and the consultation is 100% free of charge.</h6>
<p>In the event, they win your case, your attorneys will receive a contingency fee based on the funds they recover to pay for costs.</p>
<h5>You pay nothing unless you win.</h5>
<div class="btn-div">
                                <a href="javascript:;">See if I Qualify for Compensation ➔</a>
                            </div>
				</div>
				</div>
			</div>
		</div>
	</section>
<?php include 'footer.php';?>
