<?php include 'header.php';?>

	<section class="banner_section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-3">
					<div class="img-div">
						<img src="./images/banner_img_1.png" class="img-fluid" alt="">
					</div>
				</div>
				<div class="col-md-4">
					<div class="content_side">
						<h1>ATTENTION WOMEN:</h1>
						<h4>If You Have Cancer & Have Used Baby Powder, You May be Entitled to <span>Significant</span> Compensation</h4>
						<ul>
							<li>Johnson & Johnson powders were <span>proven to contain asbestos</span> (a cancer causing agent)</li>
							<li>J&J recently agreed to an <span>$8.9 Billion</span> settlement for victims</li>
							<li><span>No risk or up front cost,</span> but time is running out - Apply Today!</li>
						</ul>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form_div">
						<div class="form_top">
						<h4>Find Out If You Qualify</h4>
						<p><span>Significant</span> Compensation May Be Available</p>
						
						</div>
						<form action="" >
							<label for="">Approximately how long did you or a loved one use Talcum Powder for feminine hygiene? <span>*</span></label>
							<select name="" class="form-control mb-3" id="" >
								<option value="" muted disabled selected>-- Select one --</option>
								<option value="">Less than 1 year</option>
								<option value="">2-4 years</option>
								<option value="">4-5 years</option>
								<option value="">5-9 years</option>
								<option value="">10 or more years</option>
								<option value="">Never used Talcum Powder</option>

							</select>
							<label for="">What illness did you suffer from as a result of using Talcum Powder? <span>*</span></label>
							<select autocomplete="off"  class="form-input form-control required  form-input-inner-shadow " data-at="form-select" name="What illness did you suffer from as a result of using Talcum Powder? *" data-describedby="form-validation-error-box-element-192" title="What illness did you suffer from as a result of using Talcum Powder? *" required="" aria-required="true">
						<option class="hidden" value="" disabled="" selected="">-- Select one--</option>
						<option class="form-select-option" value="Endometrioid Ovarian cancer" data-at="form-select-option">Endometrioid Ovarian cancer</option>
						<option class="form-select-option" value="Fallopian Tube cancer" data-at="form-select-option">Fallopian Tube cancer</option>
						<option class="form-select-option" value="Mesothelioma" data-at="form-select-option">Mesothelioma</option>
						<option class="form-select-option" value="Ovarian cancer" data-at="form-select-option">Ovarian cancer</option>
						<option class="form-select-option" value="Peritoneal cancer" data-at="form-select-option">Peritoneal cancer</option>
						<option class="form-select-option" value="Serous Epithelial Ovarian cancer" data-at="form-select-option">Serous Epithelial Ovarian cancer</option>
						<option class="form-select-option" value="Other cancer" data-at="form-select-option">Other cancer</option>
						<option class="form-select-option" value="Other injury" data-at="form-select-option">Other injury</option>
						<option class="form-select-option" value="No cancer" data-at="form-select-option">No cancer</option>
					</select>
							<label for="">In what year were you diagnosed with cancer? <span>*</span></label>
							<select autocomplete="off" class="form-input form-control required  form-input-inner-shadow " data-at="form-select" name="In what year were you diagnosed with cancer? *" data-describedby="form-validation-error-box-element-192" title="In what year were you diagnosed with cancer? *" required="" aria-required="true">
      <option class="hidden" value="" disabled="" selected="">-- Select one--</option>
      <option class="form-select-option" value="2000-2007" data-at="form-select-option">2000-2007</option>
      <option class="form-select-option" value="2008-2009" data-at="form-select-option">2008-2009</option>
      <option class="form-select-option" value="2010-2017" data-at="form-select-option">2010-2017</option>
      <option class="form-select-option" value="2018 or after" data-at="form-select-option">2018 or after</option>
      <option class="form-select-option" value="Not sure" data-at="form-select-option">Not sure</option>
      <option class="form-select-option" value="Not diagnosed with cancer" data-at="form-select-option">Not diagnosed with cancer</option>
  </select>
							<div class="form-group">
								<label for="">first Name <span>*</span></label>
								<input type="text" name="first_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Last Name <span>*</span></label>
								<input type="text" name="last_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Email <span>*</span></label>
								<input type="email" name="email" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Phone Number <span>*</span></label>
								<input type="number" name="phone_no" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Briefly describe what happened (Optional)</label>
								<textarea name="" class="form-control" id="" cols="30" rows="4"></textarea>
							</div>
							<div class="btn-div">
                                <a href="javascript:;">Do I qualify?</a>
                            </div>
							<div class="img-div py-4 text-center">
								<img src="./images/c_s_img.png" class="img-fluid" alt="">
							</div>
						 <p>By clicking 'Do I Qualify' and submitting my request, I confirm that I have read and agree to the privacy policy of this site and that I consent to receive emails, phone calls and/or text message offers and communications from Total Injury Help, Digital Activity, and its network of lawyers and advocates at any telephone number or email address provided by me, including my wireless number, if provided. I understand there may be a charge by my wireless carrier for such communications. I understand these communications may be generated using an autodialer and may contain pre-recorded messages and that consent is not required to utilize Total Injury Help services. I understand that this authorization overrides any previous registrations on a federal or state Do Not Call registry. Accurate information is required for a free evaluation.</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="first_wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul>
						<li><h5>As Seen On:</h5></li>
						<li>
							<img src="./images/m_log_1.png" alt="">
						</li>
						<li>
							<img src="./images/m_log_2.png" alt="">
						</li>
						<li>
							<img src="./images/m_logo_3.png" alt="">
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="second_wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="row">
						<div class="col-md-7">
							<div class="content">
								<h2>
J&J Ordered to Pay Billions in Baby Powder Cancer Lawsuits, but Time is Running Out!</h2>
<p>In April 2023, Johnson & Johnson agreed to increase settlement amounts to <span>$8.9 billion for victims and their families</span> over baby powder cancer injury claims including:</p>
							</div>
						</div>
						<div class="col-md-4">
							<img src="./images/j_powder.svg" alt="">
						</div>
					</div>
					<div class="row">
						<div class="col-md-10">
							<ul>
								<li><p><span>$55 million</span> to a South Dakota woman diagnosed with cancer</p></li>
								<li><p><span>$10 million</span> to a woman in Virginia who developed cancer after baby powder use
</p></li>
								<li><p><span>$417 million</span> to a woman in California who blamed baby powder for her cancer
</p></li>
								<li><p><span>$70 million</span> to a Missouri woman who also developed cancer after talc use
</p></li>
								<li><p><span>$55 million</span> to the family of a woman who died from ovarian cancer
</p></li>
								<li><p><span>$117 million</span> to a man who blamed his mesothelioma on baby powder use
</p></li>
								<li><p><span>$4.6 billion</span> to 22 women who were diagnosed with ovarian cancer after baby powder use






</p></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<section class="running_out_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 ">
                    <h3>Time is running out - Fill out the form to see if you qualify!</h3>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>1. Complete the Form </h4>
                        <p>Johnson & Johnson has already been ordered to pay billions in lawsuits but time is running
                            out. Complete the form <span>TODAY</span> to make sure you have the best chance to recieve the justice
                            you deserve.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>2. Free Case Review</h4>
                        <p>Our team will call you as soon as possible, usually within 15 minutes, to discuss your
                            options and collect information needed to get the settlement you deserve. This is completely
                            free with no obligations.

                        </p>


                    </div>
                </div>
                <div class="col-md-4">
                    <div class="content">
                        <h4>3. Possible Compensation</h4>
                        <p>Your attorney will fight for you to receive the best possible compensation. There are no up
                            front costs to you. Your attorney will only get paid when a settlement is won for your case.

                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="Johnson_Johnson_section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2>Johnson & Johnson knowingly endangered the lives of their consumers – it’s time for them to pay
                        for the damage they’ve caused!</h2>
                    <p class="pt-3">The FDA recently released a health and safety warning to consumers after
                        <span>Johnson and
                            Johnson added cancer-causing asbestos to their baby powders and hid it from the
                            public.</span></p>
                    <p>The company continued to profit off trusting customers who were getting sick from these dangerous
                        products. </p>
                    <p>The time has come for Johnson & Johnson to pay for the damage they’ve caused to so many women and
                        their families. <span>Juries have already ordered the company to pay billions of dollars to
                            innocent victims, but time is running out.
                            If you or someone you love has been diagnosed with cancer after using Johnson & Johnson baby
                            powder,<span>it’s time to take a stand.

                            </span>
                            <p>Don’t wait! <span> See if you qualify for significant compensation before it’s too late.
                                </span>
                            <p>
                            <div class="btn-div">
                                <a href="javascript:;">Do I qualify?</a>
                            </div>
                </div>
                <div class="col-md-4">
                    <div class="img-div">
                        <img src="./images/john_p_img.png"
                            class="img-fluid" alt="">
                        <img class="powder_img img-fluid"
                            src="./images/p_1.png"
                            alt="">
                        <img class="powder_img_2 img-fluid"
                            src="./images/p_2.png"
                            alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php include 'footer.php';?>
