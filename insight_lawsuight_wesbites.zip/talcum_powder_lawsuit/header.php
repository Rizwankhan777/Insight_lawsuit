<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Talcum Powder Lawsuit - Free Case Evaluation</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="images/favicon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/jquery.fancybox.min.css">
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/responsive.css" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">


</head>

<body>
	<header class="desktop_header">
		<div class="container">
		<div class="row">
				<div class="col-4 col-sm-6  col-md-4">
					<!-- <img src="./images/t_injury_img.png" class="img-fluid" alt=""> -->
					<h6 class="py-md-2 text-white text-center">Insight Lawsuit</h6>
				</div>
			    <div class="col-8 col-sm-6 col-md-4  text-center py-2">
					<h4>TIME IS LIMITED TO FILE!</h4>
				</div>
			</div>
		</div>
	</header>
    

	
<!-- 
	fancybox images link
	<a data-fancybox="gallery" href="images/logo.png"><img src="images/logo.png"></a>
	<a data-fancybox="gallery" href="images/logo.png"><img src="images/logo.png"></a>
 -->