<?php include 'header.php';?>

	<section class="banner_section web2">
		<div class="container">
			<div class="row">
			
				<div class="col-md-7">
					<div class="content_side">
						<h1>ATTENTION:</h1>
						<h4>Paraquat Lawsuits</span></h4>
						<h5>Paraquat lawsuits claim that long-term paraquat exposure causes Parkinson’s disease. Plaintiffs diagnosed with Parkinson’s disease say manufacturers failed to warn users about the risk. If you were exposed to paraquat and later developed Parkinson's disease, you may qualify for compensation.</h5>

					</div>
				</div>
				<div class="col-md-5">
					<div class="form_div">
						<div class="form_top">
						<h4>Find Out If You Qualify</h4>
						<p><span>Significant</span> Compensation May Be Available</p>
						
						</div>
						<form action="" >
							<label for="">Did you or a loved one serve, live, or work at Camp Lejeune for at least 30 days between 1953 and 1987?</label>
							<select name="" class="form-control mb-3" id="" >
								<option value="" muted disabled selected>-- Select one --</option>
								<option value="">Yes</option>
								<option value="">No</option>
								

							</select>
							<label for="">What injury were you or your loved one diagnosed with?

</label>
<select autocomplete="off"  class="form-input form-control required   " data-at="form-select" name="What injury were you or your loved one diagnosed with?" data-describedby="form-validation-error-box-element-516" title="What injury were you or your loved one diagnosed with?" required="" aria-required="true">
      <option class="hidden" value="" disabled="" selected="">-- Select one--</option>
      <option class="form-select-option" value="Aplastic anemia" data-at="form-select-option">Aplastic anemia</option>
      <option class="form-select-option" value="Amyotrophic Lateral Sclerosis (ALS)" data-at="form-select-option">Amyotrophic Lateral Sclerosis (ALS)</option>
      <option class="form-select-option" value="Birth defects (non-cardiac)" data-at="form-select-option">Birth defects (non-cardiac)</option>
      <option class="form-select-option" value="Bladder cancer" data-at="form-select-option">Bladder cancer</option>
      <option class="form-select-option" value="Brain cancer" data-at="form-select-option">Brain cancer</option>
      <option class="form-select-option" value="Breast Cancer" data-at="form-select-option">Breast Cancer</option>
      <option class="form-select-option" value="Cardiac birth defects" data-at="form-select-option">Cardiac birth defects</option>
      <option class="form-select-option" value="Cervical cancer" data-at="form-select-option">Cervical cancer</option>
      <option class="form-select-option" value="Esophageal cancer" data-at="form-select-option">Esophageal cancer</option>
      <option class="form-select-option" value="Female Infertility (while exposed to CL water)" data-at="form-select-option">Female Infertility (while exposed to CL water)</option>
      <option class="form-select-option" value="Fetal death (loss > 20 weeks)" data-at="form-select-option">Fetal death (loss &gt; 20 weeks)</option>
      <option class="form-select-option" value="Hepatic steatosis (fatty liver disease)" data-at="form-select-option">Hepatic steatosis (fatty liver disease)</option>
      <option class="form-select-option" value="Kidney cancer" data-at="form-select-option">Kidney cancer</option>
      <option class="form-select-option" value="Kidney disease" data-at="form-select-option">Kidney disease</option>
      <option class="form-select-option" value="Leukemia" data-at="form-select-option">Leukemia</option>
      <option class="form-select-option" value="Lung cancer" data-at="form-select-option">Lung cancer</option>
      <option class="form-select-option" value="Liver cancer" data-at="form-select-option">Liver cancer</option>
      <option class="form-select-option" value="MDS (Myelodysplastic syndromes)" data-at="form-select-option">MDS (Myelodysplastic syndromes)</option>
      <option class="form-select-option" value="Multiple myeloma" data-at="form-select-option">Multiple myeloma</option>
      <option class="form-select-option" value="Miscarriage (loss < 20 weeks while exposed to CL water)" data-at="form-select-option">Miscarriage (loss &lt; 20 weeks while exposed to CL water)</option>
      <option class="form-select-option" value="Neural tube defects" data-at="form-select-option">Neural tube defects</option>
      <option class="form-select-option" value="Non-Hodgkin's lymphoma" data-at="form-select-option">Non-Hodgkin's lymphoma</option>
      <option class="form-select-option" value="Pancreatic cancer" data-at="form-select-option">Pancreatic cancer</option>
      <option class="form-select-option" value="Parkinson's disease" data-at="form-select-option">Parkinson's disease</option>
      <option class="form-select-option" value="Rectal cancer" data-at="form-select-option">Rectal cancer</option>
      <option class="form-select-option" value="Renal toxicity" data-at="form-select-option">Renal toxicity</option>
      <option class="form-select-option" value="Scleroderma" data-at="form-select-option">Scleroderma</option>
      <option class="form-select-option" value="Soft tissue sarcoma" data-at="form-select-option">Soft tissue sarcoma</option>
      <option class="form-select-option" value="Other cancer" data-at="form-select-option">Other cancer</option>
      <option class="form-select-option" value="Other injury" data-at="form-select-option">Other injury</option>
      <option class="form-select-option" value="No injury" data-at="form-select-option">No injury</option>
  </select>
						
							<div class="form-group">
								<label for="">first Name <span>*</span></label>
								<input type="text" name="first_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Last Name <span>*</span></label>
								<input type="text" name="last_name" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Email <span>*</span></label>
								<input type="email" name="email" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Phone Number <span>*</span></label>
								<input type="number" name="phone_no" class="form-control">
							</div>
							
							<div class="form-group">
								<label for="">Briefly describe what happened (Optional)</label>
								<textarea name="" class="form-control" id="" cols="30" rows="4"></textarea>
							</div>
						 <p>
						 <div class="btn-div">
                                <a href="javascript:;">Do I qualify?</a>
                            </div>
							<div class="img-div py-3 text-center">
								<img src="./images/c_s_img.png" class="img-fluid" alt="">
							</div>
							<p>
							By clicking 'Do I Qualify' and submitting my request, I confirm that I have read and agree to the privacy policy of this site and that I consent to receive emails, phone calls and/or text message offers and communications from Total Injury Help, Digital Activity, and its network of lawyers and advocates at any telephone number or email address provided by me, including my wireless number, if provided. I understand there may be a charge by my wireless carrier for such communications. I understand these communications may be generated using an autodialer and may contain pre-recorded messages and that consent is not required to utilize Total Injury Help services. I understand that this authorization overrides any previous registrations on a federal or state Do Not Call registry. Accurate information is required for a free evaluation.

</p>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="first_wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul>
						<li><h4>As Seen On:</h4></li>
						<li>
							<img src="./images/ab_new_img.png" alt="">
						</li>
						<li>
							<img src="./images/m_log_1.png" alt="">
						</li>
						<li>
							<img src="./images/forb_img.webp" alt="">
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="second_wrap web2_wrap2">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-12">
							<div class="content">
								<h2>Why Paraquat Lawsuits Are Being Filed</h2>
								<p>People exposed to paraquat who developed Parkinson’s disease filed lawsuits against Syngenta, Chevron and other defendants seeking compensation and holding corporations accountable for negligence.</p>

								<h4>Reasons to seek a paraquat lawyer and file a paraquat lawsuit include:</h4>
<ul>
	<li><span>Compensation for Injuries.</span> There is no cure for Parkinson’s disease, and people with the disease will have to undergo treatment for the rest of their lives.
</li>
<li><span>Hold Companies Accountable.</span> People who filed paraquat lawsuits claim manufacturers knew the weed killer was toxic for years and that it could cause Parkinson’s disease. Despite this, they continued to sell it and concealed this information from plaintiffs and others.
</li>
<li><span>Spread Awareness.</span> Paraquat has been used in commercial farming and agriculture in the United States since the 1960s. Each year more people are exposed to it. Some people use it on the job, while others live near farms that use the toxic weed killer.
</li>
</ul>
<p>Parkinson’s disease can be debilitating. Filing a paraquat lawsuit may help secure compensation to pay for costly medical bills, lost wages and other expenses for past and future care. You may also receive compensation for physical and emotional pain and suffering as well as loss of quality of life.</p>
							</div>
						</div>
						
					</div>

					
				</div>
			</div>
		</div>
	</section>

	<section class="paraquat_lawsuit_updates">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="content">
						<h1>Paraquat Lawsuit Updates</h1>
						<p>As of August 22, 2023, there were 4,554 paraquat lawsuits pending in Illinois federal court. The first bellwether trial was scheduled for July 2023 but has since been moved to October 2023.</p>
						<h4>Paraquat updates and court proceedings include:</h4>
						<ul>
							<li><span>April 21, 2023:</span> Status conference.</li>
							<li><span>April 17, 2023:</span> Deadline for summary judgment and Daubert motions to be filed.</li>
							<li><span>June 26, 2023: </span>Hearing on summary judgment and Daubert motions.
</li>
<li><span>October 3, 2023:</span> Final pretrial conference.
</li>
<li><span>October 16, 2023:</span> First jury trial.
</li>
						</ul>
						<p>The majority of paraquat claims are in the Illinois MDL, but another large group of paraquat lawsuits formed in the Philadelphia Court of Common Pleas. A judge signed an order on March 31, 2023, allowing cases to proceed with a short-form complaint</p>
						<p>“Lawsuits have been filed in the state courts of California, Florida, Pennsylvania and Washington. The first state court trial is scheduled to begin on Sept. 5, 2023, in California. An additional state court trial is scheduled to begin Jan. 8, 2024, in Florida,” according to Syngenta’s 2022 annual report.</p>
						<h2>Who Can File a Paraquat Lawsuit?</h2>
						<p>People who worked around paraquat or were exposed to paraquat regularly and later developed Parkinson’s disease may be eligible to file a paraquat lawsuit for compensation.</p>
						<p>Most people exposed to paraquat work in commercial agriculture or live near commercial farms. Paraquat is a restricted-use herbicide. This means only licensed, trained applicators can use it, and it’s not licensed for home use.</p>
						<p>Those who live near farms may be exposed through spray drift or contaminated water. People who live with licensed applicators may be exposed through contaminated clothing or equipment and by accompanying applicators to work sites.</p>
						<h4>People who may qualify to file paraquat lawsuits include:</h4>
						<ul>
							<li>Agricultural workers, including farmers, licensed paraquat applicators, growers, pickers and landscapers
</li>
<li>People who live near farmland sprayed with paraquat
</li>
<li>Anyone who works around commercial weed killers and pesticides
</li>
						</ul>
						<p>Contacting a paraquat lawyer is the only way to be sure you qualify. There are time limits to file a lawsuit, so you should contact a lawyer right away. Some types of paraquat exposure are more difficult to determine than others, but an experienced paraquat attorney can help prove your case.</p>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php include 'footer.php';?>

